![](https://img.shields.io/badge/Foundry-v0.8.6-informational)
![Latest Release Download Count](https://img.shields.io/github/downloads/kandashi/rarity-colors/latest/module.zip)
![Forge Installs](https://img.shields.io/badge/dynamic/json?label=Forge%20Installs&query=package.installs&suffix=%25&url=https%3A%2F%2Fforge-vtt.com%2Fapi%2Fbazaar%2Fpackage%2Frarity-colors&colorB=4aa94a)
[![Discord Server](https://img.shields.io/badge/-Discord-%232c2f33?style=flat-square&logo=discord)](https://discord.gg/hHM6Jfb4rH)
# Rarity Colors

Give your Inventory and Sidebar a splash of color. Re-colors Actor Inventory Items and the Items Sidebar names with colors based on item rarity and type

## Colors are as follows

- Uncommon Items - Green
- Rare Items - Blue
- Very Rare Items - Purple
- Legendary Items - Orange
- Artifact Items - Brown/Dark Orange
- Spells - Light blue
- Features - Terqouise 

![image](https://user-images.githubusercontent.com/1347785/140974008-cc790018-4fb3-410b-a856-9993cfba498b.png)
